@extends('dashboard.layouts.main')
@section('ds_container')
<div class="container-fluid d-flex min-vh-100 p-3 mx-auto flex-column justify-content-center align-items-center blbg">
    <img src="/../assets/logo/coming_soon.png" alt="kosong" style="width: 80%">
</div>
@endsection