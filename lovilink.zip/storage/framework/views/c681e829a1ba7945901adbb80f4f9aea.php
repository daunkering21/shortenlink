
<?php $__env->startSection('container'); ?>
<div class="container-fluid ldlp03 p-3 min-vh-100">
    <div class="container d-flex justify-content-center m-5 ">
        <div class="col-6">
            <div class="card">
                <div class="card-header text-center">
                    <span class="text-purple bold">Login Page</span>
                </div>
                <div class="card-body height70dvh">
                    <form method="POST" action="/login">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3 text-center">
                            <label for="username" class="form-label"><span class="text-secondary bold">Username/Email</span></label>
                            <input type="text" class="form-control text-center" id="username" name="user" placeholder='" Enter your username/email... "'>
                        </div>
                        <div class="mb-3 text-center">
                            <label for="password" class="form-label"><span class="text-secondary bold">Password</span></label>
                            <input type="password" class="form-control text-center" id="password" name="password" placeholder='" Tell me your secret..  "'>
                        </div>
                        <div class="mb-3 text-center">
                            <label for="confirm_password" class="form-label"><span class="text-secondary bold">Password Confirmation</span></label>
                            <input type="password" class="form-control text-center" id="confirm_password" name="confirm_password" placeholder='" Confirm the secret again... "'>
                        </div>
                        <div class="mb-3 form-check">
                            <input type="checkbox" class="form-check-input" id="remember_me" name="remember_token">
                            <label class="form-check-label" for="remember_me">Remember Me! </label>
                        </div>
                        <button type="submit" class="btn btn-purple">Submit</button>
                    </form>
                </div>
                <div class="card-footer text-body-secondary text-center">
                    Welcome to <span class="text-warning bold">Lov</span><span class="text-purple bold">Idea</span> Shorten link, we value your privacy.
                </div>
            </div>
        </div>
        
        <div class="col-2"></div>
        <div class="col-4">
            
        </div>
    </div>
</div>
<?php $__currentLoopData = [
    'user',
    'password',
    'confirm_password',
]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kalauError): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php $__errorArgs = [$kalauError];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <script>
            Swal.fire([
                text: '<?php echo e($message); ?>',
                icon: 'error',
                confirmButtonText: 'OK',
            ]);
        </script>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\L21\Documents\MT21\Aplikasi\Applications\global_bl\shorten-link\resources\views/front/login.blade.php ENDPATH**/ ?>