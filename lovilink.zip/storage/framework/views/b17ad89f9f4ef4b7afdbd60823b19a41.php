
<?php $__env->startSection('container'); ?>
<div class="container-fluid min-vh-100">
    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\L21\Documents\MT21\Aplikasi\Applications\global_bl\shorten-link\resources\views/front/blogs.blade.php ENDPATH**/ ?>