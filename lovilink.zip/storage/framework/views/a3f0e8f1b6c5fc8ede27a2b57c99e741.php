
<?php $__env->startSection('ds_container'); ?>
<div class="container-fluid min-vh-100 blbg">
    <div class="container mt-3">
        <div class="col-lg">
            <div class="card d-flex">
                <div class="card-header text-center bg-gray-100">
                    <span class="text-purple bold">Shorten Link</span>
                </div>
                <div class="card-body text-center">
                    <form action="/dashboard/link/<?php echo e($username); ?>/<?php echo e($data['custom_url']); ?>" method="POST">
                        <?php echo method_field('put'); ?>
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="url" class="form-label"><span class="text-secondary bold">Target URL</span></label>
                            <input type="text" class="form-control text-center bg-grey-10" id="url" name="url" placeholder='" Put your target URL here "' value="<?php echo e($data['original_url']); ?>">
                        </div>
                        <div class="mb-3">
                            <label for="custom_url" class="form-label"><span class="text-secondary bold">Your Custom URL</span></label>
                            <input type="text" class="form-control text-center bg-grey-10" id="custom_url" name="custom_url" placeholder='" www.lovilink.com/ Your URL Here "' value="<?php echo e($data['custom_url']); ?>">
                        </div>
                        <div class="mb-3">
                            <label for="title" class="form-label"><span class="text-secondary bold">Title</span></label>
                            <input type="text" class="form-control text-center bg-grey-10" id="title" name="title" placeholder='" Title for URL "' value="<?php echo e($data['title']); ?>">
                        </div>
                        <div class="mb-3">
                            <label for="description" class="form-label"><span class="text-secondary bold">Description</span></label>
                            <textarea class="form-control text-center bg-grey-10" id="description" name="description" placeholder='" Put you description here to describe your url "'><?php echo e($data['description']); ?></textarea>
                        </div>
                        <button type="submit" class="btn btn-success"><span class="text-white bold">Update</span></button>
                        <a href="/dashboard/link/<?php echo e($username); ?>" class="btn btn-warning"><span class="text-purple bold">Back</span></a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\L21\Documents\MT21\Aplikasi\Applications\global_bl\shorten-link\resources\views/dashboard/link/edit.blade.php ENDPATH**/ ?>