<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" >
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.19/dist/sweetalert2.all.min.js"></script>
    <title>LovIdea Short Link</title>
    <link rel="icon" type="image/x-icon" href="/../root/lovidea.ico">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Kanit:wght@400;700&display=swap" >
    <link rel="stylesheet" href="/../assets/css/style.css">
    <link rel="stylesheet" href="/../assets/css/dsstyle.css">
</head>
<body>
    <script src="https://cdn.jsdelivr.net/npm/prismjs@1.24.1"></script>
    <?php echo $__env->make('dashboard.partial.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="wrapper">
        <?php echo $__env->make('dashboard.partial.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('ds_container'); ?>
    </div>
    
    <div class="card text-center mt-auto">
        <div class="card-footer text-body-secondary">
            Copyright© - All rights reserved 2024.
        </div>
        </div>
    <?php if(session()->has('success')): ?>
    <script>
        Swal.fire({
            text: '<?php echo e(session('success')); ?>',
            icon: 'success',
            confirmButtonText: 'OK'
        });
    </script>
    <?php elseif(session()->has('error')): ?>
    <script>
        Swal.fire({
            text: '<?php echo e(session('error')); ?>',
            icon: 'error',
            confirmButtonText: 'OK'
        });
    </script>
    <?php endif; ?>
    <script src="/../assets/js/script.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.19/dist/sweetalert2.all.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html><?php /**PATH C:\Users\L21\Documents\MT21\Aplikasi\Applications\global_bl\shorten-link\resources\views/dashboard/layouts/main.blade.php ENDPATH**/ ?>