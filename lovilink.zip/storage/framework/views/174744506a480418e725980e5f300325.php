
<?php $__env->startSection('ds_container'); ?>
<div class="container-fluid d-flex min-vh-100 p-3 mx-auto flex-column justify-content-center align-items-center blbg">
    <img src="/../assets/logo/coming_soon.png" alt="kosong" style="width: 80%">
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\L21\Documents\MT21\Aplikasi\Applications\global_bl\shorten-link\resources\views/dashboard/homepage.blade.php ENDPATH**/ ?>